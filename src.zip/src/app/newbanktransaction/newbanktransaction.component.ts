import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-newbanktransaction',
  templateUrl: './newbanktransaction.component.html',
  styleUrls: ['./newbanktransaction.component.css']
})
export class NewbanktransactionComponent implements OnInit {
  userName: any;
  showmsg:boolean ;
  public bankTranasctionFrm: FormGroup;
  refer:any;
  customrnmbr:any;
  custnmbr:any;



  constructor(
    public router:Router,
    public formbuilder:FormBuilder,

  ) { 
    if(JSON.parse(localStorage.getItem(("Username"))) != undefined && JSON.parse(localStorage.getItem("Username"))!=""){
      this.userName = JSON.parse(localStorage.getItem(("Username")));
    }
    if(this.userName != ""){
      this.customrnmbr = "cus".toUpperCase();
        this.bankTranasctionFrm.value.custnmbr = this.customrnmbr;
    }
    

  }

  ngOnInit() {
      
    this.bankTranasctionFrm = this.formbuilder.group({   
      refer:['',[Validators.required]],
      custnmbr: ['', [Validators.required]],
      custname:['', [Validators.required]],
      custaddr:['', [Validators.required]],
      custphnmbr:['',[Validators.required]],
      trnsframnt:['',[Validators.required]],
      curencySelect:['',[Validators.required]],
      benecrybank:['',[Validators.required]],
      benecryacntnumbr:['',[Validators.required]],
      paymnt:['',[Validators.required]],
    });  
  }
  onClickval(){
    this.router.navigate(['userlogin']);
  }

  onClickBack(){
    this.router.navigate(['mainpage']);
  }

  submitBtnClick(){
    this.router.navigate(["submitedtranaction"]);
  }
  clearBtnClick(){
  }

}
