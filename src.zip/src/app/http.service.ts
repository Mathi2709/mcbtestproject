import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  baseUrl:string = "http://localhost:3000/";
  
  constructor(
    public http: HttpService
  ) { }

  async ajaxAuthservice(){

  }
  


}
