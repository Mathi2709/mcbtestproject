import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-submitedtranaction',
  templateUrl: './submitedtranaction.component.html',
  styleUrls: ['./submitedtranaction.component.css']
})
export class SubmitedtranactionComponent implements OnInit {

  constructor(
    public router:Router
  ) { }

  ngOnInit() {
  }

  onClickval(){
    this.router.navigate(['userlogin']);
  }

  onClickBack(){
    this.router.navigate(['newbanktransaction']);
  }

  

}
