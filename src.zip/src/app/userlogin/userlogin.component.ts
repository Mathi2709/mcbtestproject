import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  public mainGrp: FormGroup;
  username: any;  
  passwrd: string = "password";
  showmsg:boolean ;
  showmsg1:boolean ;


  
  constructor(
    public formbuilder:FormBuilder,
    public router: Router,
  ) {     
  
  }

  ngOnInit() {   
    this.showmsg = false;
    this.showmsg1= false;
    this.mainGrp = this.formbuilder.group({   
      username:['',[Validators.required]],
      passwrd: ['', [Validators.required]],
    });     
  }

  onFocus(){    
    if(this.mainGrp.value.username == "" ||this.mainGrp.value.username == undefined ){
      this.showmsg = true;
    }  if(this.mainGrp.value.passwrd == "" || this.mainGrp.value.passwrd == undefined ){
      this.showmsg1 = true;
    }if(this.mainGrp.value.username != "" && this.mainGrp.value.username != undefined){
      this.showmsg = false;
    }if(this.mainGrp.value.passwrd != "" && this.mainGrp.value.passwrd != undefined){
      this.showmsg1 = false;
    }
  }

  //Mathivathani
  //Method  to submit loginform

  onClickSubmit(){
  if(this.mainGrp.value.username == "" ||this.mainGrp.value.username == undefined ){
    this.showmsg = true;
  }  if(this.mainGrp.value.passwrd == "" || this.mainGrp.value.passwrd == undefined ){
    this.showmsg1 = true;
  } 
  if(this.mainGrp.value.username != "" && this.mainGrp.value.username != undefined && this.mainGrp.value.passwrd != "" && this.mainGrp.value.passwrd != undefined){
    localStorage.setItem("Username",JSON.stringify(this.mainGrp.value.username));
    this.router.navigate(["mainpage"]);
  }
}
}
  
